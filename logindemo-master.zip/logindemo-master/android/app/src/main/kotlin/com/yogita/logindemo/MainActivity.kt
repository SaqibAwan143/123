package com.yogita.logindemo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
